Image operations
================

You can use this library to perform basic raster operations, such as:

- Crop
- Scale / resize
- Color-space conversions

See the ``example/`` sub-folder `on GitHub`_ for usage.

.. _`on GitHub`: https://github.com/mike42/gfx-php/tree/master/example
